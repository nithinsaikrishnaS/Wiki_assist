from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Required for flashing messages

# In-memory user storage (for demonstration purposes)
users = {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/signin', methods=['GET', 'POST'])
def signin():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        # Check if user already exists
        if email in users:
            flash("User already exists! Please log in.")
            return redirect(url_for('login'))
        
        # Register the user
        users[email] = password
        flash("Account created! Please log in.")
        return redirect(url_for('login'))
    
    return render_template('signin.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        # Check credentials
        if email in users and users[email] == password:
            flash("Login successful!")  # Flash success message
            return redirect(url_for('query'))
        else:
            flash("Invalid email or password. Please try again.")

    return render_template('login.html')

@app.route('/query', methods=['GET', 'POST'])
def query():
    answer = ""
    if request.method == 'POST':
        user_query = request.form['query']
        # In a real application, you would call Wolfram Alpha API here
        answer = f"Answer to your query: {user_query}"  # Mock response
    return render_template('query.html', answer=answer)

if __name__ == '__main__':
    app.run(debug=True)
