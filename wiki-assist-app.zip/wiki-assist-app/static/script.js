// script.js

// Example function for form validation
function validateForm() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username === '' || password === '') {
        alert('All fields are required.');
        return false;
    }

    // Additional validation logic if needed
    return true;
}

// Function for an example animation (e.g., a fade-in effect)
window.onload = function() {
    const content = document.getElementById('content');
    content.style.opacity = 0;
    setTimeout(function() {
        content.style.transition = "opacity 1s ease-in-out";
        content.style.opacity = 1;
    }, 100);
};
